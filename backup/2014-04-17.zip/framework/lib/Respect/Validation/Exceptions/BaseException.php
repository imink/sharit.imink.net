<?php
namespace Respect\Validation\Exceptions;

class BaseException extends ValidationException
{

}

