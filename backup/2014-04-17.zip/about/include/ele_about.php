<div class="row">
    <!-- Tabs -->
    <ul class="nav nav-tabs">
        <!-- Navigation tabs (Job titles ). Use unique value in anchor tags. -->
        <li class="active"><a href="#tab1" data-toggle="tab">About Us</a></li>
   </ul>

   <div class="tab-content">
   <br />
        <!-- In "id", use the value which you used in above anchor tags -->
        <div class="tab-pane active" id="tab1">
            <!-- Content -->
            <h4 class="title">About Us</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis vulputate eros nec odio egestas in dictum nisi vehicula. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Suspendisse porttitor luctus imperdiet. <a href="#">Praesent ultricies</a> enim ac ipsum aliquet pellentesque. Nullam justo nunc, dignissim at convallis posuere, sodales eu orci. Duis a risus sed dolor placerat semper quis in urna. Nam risus magna, fringilla sit amet blandit viverra, dignissim eget est. Ut <strong>commodo ullamcorper risus nec</strong> mattis. Fusce imperdiet ornare dignissim. Donec aliquet convallis tortor, et placerat quam posuere posuere. Morbi tincidunt posuere turpis eu laoreet. Nulla facilisi. Aenean at massa leo. Vestibulum in varius arcu.</p>
            <ul>
                <li>Etiam adipiscing posuere justo, nec iaculis justo dictum non</li>
                <li>Cras tincidunt mi non arcu hendrerit eleifend</li>
                <li>Aenean ullamcorper justo tincidunt justo aliquet et lobortis diam faucibus</li>
                <li>Maecenas hendrerit neque id ante dictum mattis</li>
                <li>Vivamus non neque lacus, et cursus tortor</li>
            </ul>
            <p> Nam risus magna, fringilla sit amet blandit viverra, dignissim eget est. Ut <strong>commodo ullamcorper risus nec</strong> mattis. Fusce imperdiet ornare dignissim. Donec aliquet convallis tortor, et placerat quam posuere posuere. Morbi tincidunt posuere turpis eu laoreet. Nulla facilisi. Aenean at massa leo. Vestibulum in varius arcu.</p>
        </div>
                                
     
   </div>
<br />
</div>