<?php
require_once("./framework/import.php");
SharIt::page()->setTitle("Login");

$loginForm;
$loginErrors = array();

if($loginForm = SharIt::app()->post('login')){
	echo "A";
	$loginValidator = SharValidator::key('email', SharValidator::shar_username());
	echo "B";
	try {
	    $loginValidator->assert($loginForm);
	} catch(\InvalidArgumentException $e) {
		echo "C";
		$loginErrors = $e->findMessages(array('shar_username'));

	}
	if(!$loginErrors){
		echo "D";
		if(SharIt::auth()->login($loginForm['email'],$loginForm['password'])){
			echo "E";
			SharIt::app()->flashMsg()->add('s',"Login Success!");
			SharIt::app()->redirect("/",3);
		}else{
			echo "F";
			array_push($loginErrors, SharIt::auth()->getError());
		}
	}
}
echo "G";
$_LAYOUT['left'] = "hello world!";
$_LAYOUT['right'] = SharIt::app()->loadView('loginForm.php',array('loginForm'=>$loginForm,'loginFormErrors'=>$loginErrors));
echo "H";
SharIt::app()->layout(array('_LAYOUT'=>$_LAYOUT),2);
?>

