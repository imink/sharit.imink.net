<?php
require_once("./framework/import.php");

SharIt::page()->setTitle("Homepage");

$_LAYOUT['mid'] =  SharIt::app()->loadView("index_show.html");

SharIt::app()->layout(array('_LAYOUT'=>$_LAYOUT),1);
?>
