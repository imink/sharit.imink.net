<?php include(dirname(__FILE__)."/header.php") ?>
<!-- START LAYOUT -->
<div class="container">
	<?php echo $_LAYOUT['mid'] ?>
</div>
<!-- END LAYOUT -->
<?php include(dirname(__FILE__)."/footer.php") ?>