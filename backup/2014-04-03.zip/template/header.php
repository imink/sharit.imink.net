<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <!-- Title and other stuffs -->
  <title>MacKart</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600' rel='stylesheet' type='text/css'>
  <!-- Stylesheets -->
  <link href="<?php echo SHARIT_URL_APP ?>/css/bootstrap.css" rel="stylesheet">
  <!-- Pretty Photo -->
  <link href="<?php echo SHARIT_URL_APP ?>/css/prettyPhoto.css" rel="stylesheet">
  <!-- Flex slider -->
  <link href="<?php echo SHARIT_URL_APP ?>/css/flexslider.css" rel="stylesheet">
  <!-- Font awesome icon -->
  <link href="<?php echo SHARIT_URL_APP ?>/css/font-awesome.css" rel="stylesheet"> 
  <!-- Main stylesheet -->
  <link href="<?php echo SHARIT_URL_APP ?>/css/style.css" rel="stylesheet">
  <!-- Stylesheet for Color -->
  <link href="<?php echo SHARIT_URL_APP ?>/css/red.css" rel="stylesheet">
  <!-- HTML5 Support for IE -->
  <!--[if lt IE 9]>
  <script src="js/html5shim.js"></script>
  <![endif]-->
  <!-- Favicon -->
  <link rel="shortcut icon" href="<?php echo SHARIT_URL_APP ?>/image/favicon/favicon.png">
</head>

<body>
  <!-- Header starts -->
  <header>
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <!-- Logo. Use class "color" to add color to the text. -->
          <div class="logo">
            <h1><a href="#">Shar<span class="color bold">It</span></a></h1>
            <p class="meta">Share Goods and Technology</p>
          </div>
        </div>
        <div class="col-md-5 col-md-offset-3">
          <!-- Search form -->
          <form class="form-inline" role="form">
            <div class="form-group">
              <input type="email" class="form-control" id="search" placeholder="Search">
            </div>
            <button type="submit" class="btn btn-default">Search</button>
          </form>
          <div class="hlinks">
            <span>
              <!-- item details with price -->
              <a href="#cart" role="button" data-toggle="modal">3 Item(s) in your <i class="icon-shopping-cart"></i></a> -<span class="bold">$25</span>  
            </span>
            <!-- Login and Register link -->
            <span class="lr"><a href="#login" role="button" data-toggle="modal">Login</a> or <a href="#register" role="button" data-toggle="modal">Register</a></span>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- Header ends -->
  
  
  <!-- Cart, Login and Register form (Modal) -->

  <!-- Cart Modal starts -->
  <div id="cart" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4>Shopping Cart</h4>
        </div>
        <div class="modal-body">

          <table class="table table-striped tcart">
            <thead>
              <tr>
                <th>Name</th>
                <th>Quantity</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><a href="single-item.html">HTC One</a></td>
                <td>2</td>
                <td>$250</td>
              </tr>
              <tr>
                <td><a href="single-item.html">Apple iPhone</a></td>
                <td>1</td>
                <td>$502</td>
              </tr>
              <tr>
                <td><a href="single-item.html">Galaxy Note</a></td>
                <td>4</td>
                <td>$1303</td>
              </tr>
              <tr>
                <th></th>
                <th>Total</th>
                <th>$2405</th>
              </tr>
            </tbody>
          </table>

        </div>
        <div class="modal-footer">
          <a href="index.html" class="btn">Continue Shopping</a>
          <a href="checkout.html" class="btn btn-danger">Checkout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Cart modal ends -->

  <!-- Login Modal starts -->
  <?php include(dirname(__FILE__)."/partial/float_login.php") ?>
  <!-- Login modal ends -->

  <!-- Register Modal starts -->
  <?php include(dirname(__FILE__)."/partial/float_register.php") ?>
  <!-- Register modal ends -->

  <!-- Navigation -->
  <?php include(dirname(__FILE__)."/partial/nav.php") ?>
  <!-- Navigation ends -->