<?php
include("template/header.php");
?>
<div class="row">
	<div class="col-md-4">
		<h2>Hello worldHello worldHello worldHello worldHello worldHello worldHello worldHello worldHello worldHello worldHello worldHello worldHello worldHello worldHello worldHello worldHello worldHello world</h2>
	</div>
	<div class="col-md-8">
		<h2>你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好</h2>
	</div>

</div>
<?php 
include("template/footer.php");
?>


