<?php
/**
* 
*/
class SharIt
{
	/**
	 * static application
	 * @var SharApp
	 */
	private static $_app;
	private static $_page;
	private static $_db;
	private static $_auth;
	private static $_mailer;

	function __construct()
	{

	}

	public static function app(){
		if(self::$_app===null){
			self::$_app = new SharApp();
		}
		return self::$_app;
	}

	public static function page(){
		if(self::$_page===null){
			self::$_page = new SharPage();
		}
		return self::$_page;
	}

	public static function db(){
		if(self::$_db===null){
			self::$_db = new SharDB();
		}
		return self::$_db;
	}

	public static function auth(){
		if(self::$_auth===null){
			self::$_auth = new SharAuth();
		}
		return self::$_auth;
	}

	public static function mailer(){
		if(self::$_mailer===null){
			//Create a new PHPMailer instance
			$mail = new PHPMailer();
			//Tell PHPMailer to use SMTP
			$mail->isSMTP();
			$mail->Host = 'localhost';
        	$mail->Port = 25;
			self::$_mailer = $mail;
		}
		return self::$_mailer;
	}
}
