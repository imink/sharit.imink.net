<?php
namespace Respect\Validation\Exceptions;

class NotException extends AbstractGroupedException
{
}

