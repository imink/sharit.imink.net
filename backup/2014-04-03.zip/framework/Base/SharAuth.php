<?php
class SharAuth
{
	public $_error;

	function __construct()
	{
		
	}

	public function auth($username,$password){
		$username = htmlspecialchars($username);
		$password = MD5($password);	// MD5 Encryption.
		$user = SharQueryAuth::getUserForUsername($username);
		if($user==null){
			$this->_error = "No Found User";
			return;
		}else{
			if($password!=SharQueryAuth::getPasswordForUsername($username)){
				$this->_error = "Password Error";
				return $user;
			}else{
				return $user;
			}
		}
	}

	public function login($username,$password){
		$this->_error = null;
		$user = $this->auth($username,$password);
		if(isset($this->_error)){
			return false;
		}else{
			$auth = array('uid' => $user[id], 'gid' =>$user[gid], 'username'=>$user[email], 'displayname'=>$user[display_name]);
			SharIt::app()->setSession('auth',$auth);
			return true;
		}
	}

	public function getError(){
		return $this->_error;
	}


	public function getAuth(){
		if ($this->isLogin()) {
			return SharIt::app()->session('auth');
		}
		return null;
	}

	public function __get($name) 
    {
    	if ($this->isLogin()) {
    		if (array_key_exists($name, $this->getAuth())) {
    			$auth = $this->getAuth();
            	return $auth[$name];
        	}
    	}
        return null;
    }

	public function logout(){
		SharIt::app()->unsetSession('auth');
	}

	public function isLogin(){
		return SharIt::app()->session('auth')!=null;
	}

}