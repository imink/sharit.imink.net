<?php
class SharApp
{
	public $name = SHARIT_NAME;
	public $autoSession = true;

	function __construct()
	{
		if ($this->autoSession) {
			@session_start();
		}
	}

	public function createUrl($url,$para=null){
		if (substr($url, -strlen("/")) !== "/"&&$url!="") {
			if (substr($url, -strlen(".php")) !== ".php") {
				$url.=".php";
			}
		}
		$url = SHARIT_URL_APP.$url;
		if($para!=null&&is_array($para)){
			$url.='?';
			$numberOfPara = count($para);
			foreach ($para as $key => $value) {
				$url.= $key."=".$value;
				$numberOfPara--;
				if($numberOfPara!=0){
					$url.="&";
				}
			}
		}
		return $url;
	}

	public function flashMsg(){
		return new FlashMessages();
	}

	public function redirect($url, $time = 0) {
		$url = str_replace(array("\n", "\r"), '', $url); // 多行URL地址支持
		if(strpos($url, '/')===0){
			$url = SHARIT_URL_APP.$url;
		}
		if (headers_sent()) {
			$str = "<meta http-equiv='Refresh' content='{$time};URL={$url}'>";
			if ($time != 0) {
				$str .= $msg;
			}
			exit($str);
		} else {
			if (0 === $time) {
				header("Location: " . $url);
			} else {
				header("Content-type: text/html; charset=utf-8");
				header("refresh:{$time};url={$url}");
			}
			exit();
		}
	}

	public function layout($para=null,$tid=1){
		$this->render(SHARIT_PATH_TEMPLATE."/layout".$tid.".php",$para);
	}

	/**
	 *$view 使用相对于根目录的相对路径;
	 */
	public function render($view,$para=null){
		echo $this->loadView($view,$para);
	}

	/**
	 *$view 使用相对于根目录的相对路径;
	 */
	public function loadView($view,$para=null){
		if($para!=NULL&&is_array($para)){
			foreach ($para as $key => $value) {
				$$key = $value;
			}
		}
		ob_start();
        include( SHARIT_PATH_APP .'/'. $view);
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
	}

	public function session($para=null){
		if($para!=null){
			return $_SESSION[$para];
		}else
			return $_SESSION;
	}

	public function setSession($para,$value){
		$_SESSION[$para]=$value;
	}

	public function unsetSession($para){
		@session_unset($para);
	}

	public function destroySession(){
		@session_destroy();
	}

	
	public function cookie($para=null){
		if($para!=null){
			return $_COOKIE[$para];
		}else
			return $_COOKIE;
	}

	public function setCookie($name,$value,$expire){
		setcookie($name,$value,$expire);
	}

	public function unsetCookie($name){
		setcookie($name, "", time()-3600);
	}

	public function get($arg=null){
		if ($arg===null) {
			return $_GET;
		}else{
			if (!isset($_GET[$arg])) {
				return null;
			}else 
				return $_GET[$arg];
		}
		
	}

	public function post($arg=null){
		if ($arg===null) {
			return $_POST;
		}else{
			if (!isset($_POST[$arg])) {
				return null;
			}else 
				return $_POST[$arg];
		}
		
	}


}