<?php

class SharPage
{
	public $title = SHARIT_NAME;

	public $customeCSSFile = array();
	public $customeJSFile = array();
	public $customeCSS;
	public $customeJS;

	public function setTitle($title,$withSiteName=true){
		$this->title = $title;
		if($withSiteName){
			$this->title .=  " | " . SharIt::app()->name;
		}
		
	}

}