<?php
/**
 * 
 */
class SharQuery
{
	
	public static function getList(){
		$query = SharIt::db()->createCommand()->from(SharDB::tableName('product'))
            ->orderBy('status DESC')
            ->limit(5);
			->where('status', 1);
		return $query;
	}
}
?>