<?php
class SharDB
{
	private static $_pdo_connect;
	private static $tableNameList = array('product' => 'product', 'user'=>'user');
	const tablePrefix = SHARIT_DB_PREFIX;

	function __construct()
	{
		self::$_pdo_connect = new PDO('mysql:host='.SHARIT_DB_HOST.';dbname='.SHARIT_DB_NAME, SHARIT_DB_USERNAME, SHARIT_DB_PASSWORD);
	}

	public static function tableName($name){
		if(isset(self::$tableNameList[$name])){
			
			return SharDB::tablePrefix.self::$tableNameList[$name];
		}
		else{
			die("Not found Table named: " . $name);
		}
	}

	public static function connection(){
		$con = mysqli_connect(SHARIT_DB_HOST,SHARIT_DB_USERNAME,SHARIT_DB_PASSWORD,SHARIT_DB_NAME);
		if (mysqli_connect_errno()){
	  		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	  		die();
	  	}
		mysqli_query($con,"SET NAMES UTF8");
		return $con;
	}

	public static function createCommand(){
		return new FluentPDO(self::$_pdo_connect);
	}

}