<?php

class SharValidator {
	public function shar_username(){
		$validator = Respect\Validation\Validator::create();
		return $validator->email()->setName("shar_username")->setTemplate("{{input}} is Not a valid Username");
	}

	public function shar_password(){
		$validator = Respect\Validation\Validator::create();
		return $validator->string()->setName("vn_username")->setTemplate("{{input}} is Not a valid Username");
	}

	public static function __callStatic($ruleName, $arguments)
    {
		return Respect\Validation\Validator::__callStatic($ruleName, $arguments);

    }
}