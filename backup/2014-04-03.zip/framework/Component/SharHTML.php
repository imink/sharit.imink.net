<?php

class SharHTML {
	public static function alert($type,$info,$close=true){
		$string = "<div class='alert alert-$type'>";

		if($close){
			$string .= '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
		}

		if(is_array($info)){
			$string .= '<ul>';
			foreach ($info as $i) {
				$string .= "<li>$i</li>";
			}
			$string .= '</ul>';
		}else{
			$string .= $info;
		}
		$string .= '</div>';
		echo $string;
	}
}