<?php

class User {
	private $id="";
	private $username="";
	private $email="";
	private $emailConfirmed=0;	
	private $error="";
	private $valid;
	private $password;
	private $mobile="";
	
	public function isValid() {
		return($this->valid);
	}
	
	public function get_error() {
		return($this->error);
	}
	
	public function get_name() {
		return($this->username);
	}
	
	public function set_name($name) {
		$this->username=$name;
	}
	
	public function set_mobile($mobile) {
		$this->mobile=$mobile;
	}
	
	public function loadUser($email) {
		$sql="select * from users where email='" . $email . "';";
		$helper=new SQLHelper();
		$results=$helper->doSQL($sql);	// try and create user table
		$this->valid=FALSE;		
		if ($results->num_rows==0)  return;	// could not find account
		if ($row = mysqli_fetch_array($results)) {		// look for row
			$this->id=$row['ID'];
			$this->username=$row['username'];
			$this->email=$row['email'];
			$this->emailConfirmed=$row['emailConfirmed'];
			$this->password=$row['password'];
			$this->mobile=$row['mobile'];
				
		} else {
			//echo "Could not load";
			
		}
		$this->valid=TRUE;		
	}
}