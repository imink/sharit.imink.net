<html>
<head>
<link rel="stylesheet" type="text/css" href="../css/main.css">
</head>

<?php
include 'common.php';
?>
<body>

<?php
include "header.php"
?>

<br/>
<br/>
<br/>

<div class="normal" id="welcome">Welcome</div>


</body>