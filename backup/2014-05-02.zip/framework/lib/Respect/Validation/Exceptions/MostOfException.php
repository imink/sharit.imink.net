<?php
namespace Respect\Validation\Exceptions;

class MostOfException extends AtLeastException
{
}

